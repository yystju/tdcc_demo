var express = require('express');
var https = require('https');
var http = require('http');
var WebSocketServer = require('ws').Server;
var url = require('url');
var fs = require('fs');

var app = express();

app.param('id', function (req, res, next, id) {
  console.log('PARAM');
  req.data = {'id': id};
  next();
});

app.all('/usr/:id', function(req, res, next) {
  console.log('GET');
  res.send('hello -> ' + req.data.id);
  res.end();
});

app.use('/html', express.static(__dirname + '/html'));

var server = http.createServer(app);

var wss = new WebSocketServer({ 'server': server });

wss.on('connection', function connection(ws) {
  var location = url.parse(ws.upgradeReq.url, true);
  
  ws.on('message', function (message) {
    if(Buffer.isBuffer(message)) {
		console.log('[' + ws.filename + '] buffer.length := ' + message.length);
		
		if(ws.file) {
			fs.writeSync(ws.file, message, 0, message.length);
		}
		
		ws.send('[' + ws.filename + ']' + message.length + ' bytes received.', {mask: false});
	} else {
		var data = JSON.parse(message);
		
		console.log('data.name := ' + data.name);
		
		if(data.action == 'start') {
			ws.filename = data.name;
			ws.file = fs.openSync('./tmp/' + ws.filename, 'w');
		} else {
			ws.filename = null;
			fs.closeSync(ws.file);
			ws.file = null;
		}
		
		ws.send('[' + ws.filename + '] ' + data.action, {mask: false});
	}
  });
});

server.listen(8080, function() {
  console.log('Listening on ' + server.address().port);
});

//https.createServer({}, app).listen(8443);
