var wpi = require('wiring-pi');
wpi.setup('wpi');

var interval = process.argv.length > 2 ? process.argv[2] : '5000';

interval = parseInt(interval);

/*process.argv.forEach(function (val, index, array) {
  console.log(index + ': ' + val);
});
*/
var in_pin = 5;
var out_pin = 7; // 7 is 1 usually.

wpi.pinMode(in_pin, wpi.INPUT);
wpi.pinMode(out_pin, wpi.OUTPUT);

var tm = new Date();

var i = setInterval(function() {
	var r = wpi.digitalRead(in_pin);
	console.log('-- r := '+r);

	if(r) { //r is 1
		wpi.digitalWrite(out_pin, 0);
	}

	if((new Date() - tm) > interval) {
		clearInterval(i);
	}
}, 500);
